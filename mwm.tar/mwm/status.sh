#########################################################################################################
# !/bin/sh                                                                                              #
# Stylin Greymon's WMFS status.sh script                                                                #
# This status script was made with the 'cure' font in mind, and will need adjusting to fit other fonts. #
#########################################################################################################
_date() {
    date="`LC_ALL="en_EN.UTF-8" date '+%a %d %b %Y'`"
    date="\\#73B6D0\\$date \\#94B1A3\\:\\#73B6D0\\$HOUR `date '+%I:%M'`\\#94B1A3\\ "
}

_cpu(){
    cpufreq="$(eval $(awk '/^cpu /{print "previdle=" $5 "; prevtotal=" $2+$3+$4+$5 }' /proc/stat); sleep 0.4; eval $(awk '/^cpu /{print "idle=" $5 "; total=" $2+$3+$4+$5 }' /proc/stat); intervaltotal=$((total-${prevtotal:-0})); echo "$((100*( (intervaltotal) - ($idle-${previdle:-0}) ) / (intervaltotal) ))")"
    #if [ $cpufreq -lt 10 ]; then
    #    cpu="\\#94B1A3\\ \\#cecece\\C\\#94B1A3\\:\\#73B6D0\\0$cpufreq\\#94B1A3\\ "
    #fi

    cpu=" \\#cecece\\C\\#94B1A3\\ : \\#73B6D0\\$cpufreq"

  }

_memory() {
    memory_free="`free -m | awk '/Mem:/ { print $7 }'`"
    memory=" \\#cecece\\M\\#94B1A3\\ : \\#73B6D0\\$memory_free"
}

#_mpd() {
############
# mpd info
#
# <mpc> is required for "now playing" informations
#
#if [ "`mpc 2>&1 | wc -l`" -gt "1" ]; then
#if [ "`mpc | grep "^\[paused\]"`" != "" ]; then
#mpd_current=" \\#cecece\\PAUSED \\#73B6D0\\`mpc current`"
#else
#mpd_current=" \\#cecece\\PLAYING \\#73B6D0\\`mpc current`"
#fi
#else
#mpd_current=" \\#cecece\\MPD \\#73B6D0\\ [not playing]"
#fi
#mpd="\\#cecece\\$mpd_current"
#
############
#}

#_battery() {
#    REM=`awk '/remaining capacity/ { print $3 }' /proc/acpi/battery/BAT0/state`
#    LAST=`awk '/last full/ { print $4}' /proc/acpi/battery/BAT0/info`
#    bat_percent=$(echo $REM $LAST | awk '{printf "%d", ($1/$2)*100'})

#    bat_acpi=`cat /sys/class/power_supply/BAT0/status`
    #if [ "$bat_acpi" = "Discharging" ]; then
#bat_state="\\#9e2f3e\\[BAT]"
#    elif [ "$bat_acpi" = "Charging" ]; then
#bat_state="\\#8ab534\\[AC]"
#    fi
   # Blink if % < 15 (since my battery is mostly dead i will probably never see the blink :D)
#    if [ "$bat_percent" -lt "15" ]; then
#bat_fail=1
#if [ "`cat /tmp/batteryfail`" ]; then
#color="\\#9e2f3e\\"
#echo 0 > /tmp/batteryfail
#else
#color="\\#96824b\\"
#echo 1 > /tmp/batteryfail
#fi
#else
#bat_fail=0
#color="\\#73B6D0\\"
    #fi
#battery="\\#cecece\\POW\\#94B1A3\\:$color $bat_percent% $bat_state"
#}
_volume() {
volume="\\#cecece\\VOL\\#73B6D0\\ `amixer | grep "PCM" -A 5 | grep -o "\[.*%" | sed "s/\[//" | sed 's/%//'`"

}
_separateur() {
separateur="\\#E04613\\x\\#cecece\\"
}
_separateurtime() {
separateurtime="\\#E04613\\|\\#cecece\\"
}
_separateurmpd() {
separateurmpd="\\#E04613\\>>\\#cecece\\"
}

statustext() {
    # concat args
    for arg in $@; do
_${arg}
        args="${args} `eval echo '$'$arg`"
    done
mwm -s 0 "$args"
}

statustext separateur cpu separateur memory separateur volume separateur date
